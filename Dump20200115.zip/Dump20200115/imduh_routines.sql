CREATE DATABASE  IF NOT EXISTS `imduh` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `imduh`;
-- MySQL dump 10.13  Distrib 8.0.19, for Linux (x86_64)
--
-- Host: localhost    Database: imduh
-- ------------------------------------------------------
-- Server version	8.0.19

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Temporary view structure for view `average_score`
--

DROP TABLE IF EXISTS `average_score`;
/*!50001 DROP VIEW IF EXISTS `average_score`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `average_score` AS SELECT 
 1 AS `name`,
 1 AS `average`,
 1 AS `movieID`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `watch_time`
--

DROP TABLE IF EXISTS `watch_time`;
/*!50001 DROP VIEW IF EXISTS `watch_time`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `watch_time` AS SELECT 
 1 AS `hours`,
 1 AS `userID`*/;
SET character_set_client = @saved_cs_client;

--
-- Final view structure for view `average_score`
--

/*!50001 DROP VIEW IF EXISTS `average_score`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `average_score` AS select `T`.`name` AS `name`,round(avg(`T`.`score`),1) AS `average`,`T`.`movieID` AS `movieID` from (select `scores`.`mID` AS `mID`,`scores`.`uID` AS `uID`,`scores`.`score` AS `score`,`movies`.`movieID` AS `movieID`,`movies`.`name` AS `name`,`movies`.`year` AS `year`,`movies`.`description` AS `description`,`movies`.`length` AS `length` from (`scores` join `movies` on((`movies`.`movieID` = `scores`.`mID`)))) `T` group by `T`.`name`,`T`.`movieID` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `watch_time`
--

/*!50001 DROP VIEW IF EXISTS `watch_time`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `watch_time` AS select round((sum(`T`.`length`) / 60),1) AS `hours`,`T`.`userID` AS `userID` from (select `users`.`userID` AS `userID`,`users`.`username` AS `username`,`users`.`password` AS `password`,`scores`.`mID` AS `mID`,`scores`.`uID` AS `uID`,`scores`.`score` AS `score`,`movies`.`movieID` AS `movieID`,`movies`.`name` AS `name`,`movies`.`year` AS `year`,`movies`.`description` AS `description`,`movies`.`length` AS `length` from ((`users` join `scores` on((`users`.`userID` = `scores`.`uID`))) join `movies` on((`movies`.`movieID` = `scores`.`mID`)))) `T` group by `T`.`userID` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-01-15 15:59:07
